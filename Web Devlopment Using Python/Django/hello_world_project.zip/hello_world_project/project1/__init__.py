from django.http import HttpResponse
from django.shortcuts import render
def home(request):
    username= request.GET.get('username')
    password= request.GET.get('pass')
    print('Hello World')
    print(username)