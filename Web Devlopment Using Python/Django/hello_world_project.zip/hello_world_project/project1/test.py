
def login():
    username = input('Enter Your User NAME')
    password = input('Ent pass')
    if username == 'ratnam' and password == 'pass':
        print('Hello World')
print(login())