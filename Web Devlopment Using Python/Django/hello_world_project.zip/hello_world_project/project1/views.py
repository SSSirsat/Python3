from email import message
from pyexpat.errors import messages
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User


def say_hello(request):
    print(request.GET)
    print(request.POST)
    return render(request,'login.html')

def home(request):
    if request.method=="GET":
    
        username= request.GET.get('username')
        password= request.GET.get('password')
        feed_bot = authenticate(username=username, password=password)

        print('rt')
        print(request.POST.get('username'))
        print(username)
        print(password)

        if feed_bot is not None:
        # Confirmed as user credentials.
            login(request, feed_bot)
        if(username=="ratnam" and password=="pass"):
            return render(request,'homepage.html') 
        else:
            return HttpResponse("invalid password")
        
        # #user = User.objects.get(username=username)
        # #except:
        # #    user = User.objects.get(username=username)
        # user = authenticate(request, username=username,password=password)
        # #if user is not None:
        #     login(request, user)
        #     return redirect('home')
        # else:
        #     #messages.error(request,'user does not exist')
        #     pass 

        print('ratnam')
        print(request.GET)
        print(request.POST)
        context = {}

        
    else:
        return HttpResponse("404 Error")
