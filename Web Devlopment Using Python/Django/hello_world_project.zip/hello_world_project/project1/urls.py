from django.urls import path, include
from . import views

urlpatterns = [
    
    path('login',views.say_hello),
    path('home',views.home)
]
